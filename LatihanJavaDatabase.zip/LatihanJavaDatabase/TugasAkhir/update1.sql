-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               10.4.6-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for poliklinik
DROP DATABASE IF EXISTS `poliklinik`;
CREATE DATABASE IF NOT EXISTS `poliklinik` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `poliklinik`;

-- Dumping structure for table poliklinik.dokter
DROP TABLE IF EXISTS `dokter`;
CREATE TABLE IF NOT EXISTS `dokter` (
  `Id_Dokter` varchar(7) NOT NULL,
  `Jenis_Dokter` varchar(15) NOT NULL,
  `Nama` varchar(25) DEFAULT NULL,
  `TTL` varchar(20) DEFAULT NULL,
  `No_Hp` varchar(12) DEFAULT NULL,
  `Alamat` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`Id_Dokter`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.

-- Dumping structure for table poliklinik.jadwal
DROP TABLE IF EXISTS `jadwal`;
CREATE TABLE IF NOT EXISTS `jadwal` (
  `Id_Praktek` varchar(5) NOT NULL,
  `Id_Dokter` varchar(7) NOT NULL,
  `Jam_Praktek` time NOT NULL,
  `Hari` varchar(10) DEFAULT NULL,
  `Lantai` varchar(15) NOT NULL,
  `Ruangan` varchar(5) NOT NULL,
  PRIMARY KEY (`Id_Praktek`),
  KEY `Id_Dokter` (`Id_Dokter`),
  CONSTRAINT `FK_jadwal_dokter` FOREIGN KEY (`Id_Dokter`) REFERENCES `dokter` (`Id_Dokter`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.

-- Dumping structure for table poliklinik.pasien
DROP TABLE IF EXISTS `pasien`;
CREATE TABLE IF NOT EXISTS `pasien` (
  `no_reg` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(25) DEFAULT NULL,
  `no_hp` varchar(12) DEFAULT NULL,
  `alamat` varchar(30) DEFAULT NULL,
  `penyakit` varchar(20) DEFAULT NULL,
  `tgl periksa` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`no_reg`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
